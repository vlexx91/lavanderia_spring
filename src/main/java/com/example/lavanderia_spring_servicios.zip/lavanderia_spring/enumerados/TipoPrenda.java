package com.example.lavanderia_spring.enumerados;

public enum TipoPrenda {
    CAMISA, PANTALON, FALDA, VESTIDO, CHALECO, BLUSA, SHORT
}
