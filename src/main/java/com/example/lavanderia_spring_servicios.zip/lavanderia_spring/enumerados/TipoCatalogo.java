package com.example.lavanderia_spring.enumerados;

public enum TipoCatalogo {
    LAVADO, SECADO, PLANCHADO
}
